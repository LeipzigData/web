FourStore_Namespace
===============






* Class name: FourStore_Namespace
* Namespace: 





Properties
----------


### $_namespaces

```
protected mixed $_namespaces = array()
```





* Visibility: **protected**
* This property is **static**.


Methods
-------


### \FourStore_Namespace::addW3CNamespace()

```
mixed FourStore_Namespace::\FourStore_Namespace::addW3CNamespace()()
```





* Visibility: **public**
* This method is **static**.



### \FourStore_Namespace::add()

```
mixed FourStore_Namespace::\FourStore_Namespace::add()($short, $long)
```





* Visibility: **public**
* This method is **static**.

#### Arguments

* $short **mixed**
* $long **mixed**



### \FourStore_Namespace::get()

```
mixed FourStore_Namespace::\FourStore_Namespace::get()($short)
```





* Visibility: **public**
* This method is **static**.

#### Arguments

* $short **mixed**



### \FourStore_Namespace::to_sparql()

```
mixed FourStore_Namespace::\FourStore_Namespace::to_sparql()()
```





* Visibility: **public**
* This method is **static**.



### \FourStore_Namespace::to_turtle()

```
mixed FourStore_Namespace::\FourStore_Namespace::to_turtle()()
```





* Visibility: **public**
* This method is **static**.


