ParserCSV
===============






* Class name: ParserCSV
* Namespace: 







Methods
-------


### \ParserCSV::csv_to_array()

```
mixed ParserCSV::\ParserCSV::csv_to_array()($csv, $delimiter, $enclosure, $escape, $terminator)
```





* Visibility: **public**

#### Arguments

* $csv **mixed**
* $delimiter **mixed**
* $enclosure **mixed**
* $escape **mixed**
* $terminator **mixed**



### \ParserCSV::mySortAllColumn()

```
mixed ParserCSV::\ParserCSV::mySortAllColumn()($row1, $row2)
```





* Visibility: **public**

#### Arguments

* $row1 **mixed**
* $row2 **mixed**



### \ParserCSV::sortTable()

```
mixed ParserCSV::\ParserCSV::sortTable()($array)
```





* Visibility: **public**

#### Arguments

* $array **mixed**


