ParserTurtle
===============






* Class name: ParserTurtle
* Namespace: 







Methods
-------


### \ParserTurtle::turtle_to_array()

```
mixed ParserTurtle::\ParserTurtle::turtle_to_array()($turtle, $baseGraph)
```





* Visibility: **public**

#### Arguments

* $turtle **mixed**
* $baseGraph **mixed**



### \ParserTurtle::relativeToExplicitURI()

```
mixed ParserTurtle::\ParserTurtle::relativeToExplicitURI()($uri, $prefix)
```





* Visibility: **public**

#### Arguments

* $uri **mixed**
* $prefix **mixed**



### \ParserTurtle::mySortTriples()

```
mixed ParserTurtle::\ParserTurtle::mySortTriples()($itm1, $itm2)
```





* Visibility: **public**

#### Arguments

* $itm1 **mixed**
* $itm2 **mixed**



### \ParserTurtle::sortTriples()

```
mixed ParserTurtle::\ParserTurtle::sortTriples()($arrayTurtle)
```





* Visibility: **public**

#### Arguments

* $arrayTurtle **mixed**


