Net
===============






* Class name: Net
* Namespace: 







Methods
-------


### \Net::ping()

```
int Net::\Net::ping()($address)
```

Ping a address



* Visibility: **public**
* This method is **static**.

#### Arguments

* $address **mixed**



### \Net::getUrlPort()

```
mixed Net::\Net::getUrlPort()($urlInfo)
```





* Visibility: **private**
* This method is **static**.

#### Arguments

* $urlInfo **mixed**


