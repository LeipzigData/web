Base
===============






* Class name: Base
* Namespace: 





Properties
----------


### $_errors

```
private mixed $_errors
```





* Visibility: **private**


### $_max_errors

```
private mixed $_max_errors
```





* Visibility: **private**


Methods
-------


### \Base::__construct()

```
mixed Base::\Base::__construct()()
```





* Visibility: **public**



### \Base::AddError()

```
mixed Base::\Base::AddError()($error)
```





* Visibility: **public**

#### Arguments

* $error **mixed**



### \Base::GetErrors()

```
array Base::\Base::GetErrors()()
```

Give the errors



* Visibility: **public**



### \Base::ResetErrors()

```
mixed Base::\Base::ResetErrors()()
```





* Visibility: **public**


